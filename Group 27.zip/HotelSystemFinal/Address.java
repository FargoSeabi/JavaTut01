/*Address.java is a Java class that represents an address. 
 *  It has four fields: street, city, province, and code.
 * The toString() method is overridden to return the address in a readable format.
 */


record Address(String street, String city, String province, String code){
    @Override
    public String toString() {
        return street + ", " + city + ", " + province + ", " + code;
    }
}
